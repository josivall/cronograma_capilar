#include "tipos.h"

Usuario usuarios[MAX];
int qtdUsuarios = 0;
