 #ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H

// -----------------------------------------------------------------------------
// Módulo: processamento
// Propósito:
//     Executa a lógica de negócio do programa, como geração de rotinas ou
//     cálculos baseados nas informações fornecidas pelos usuários.
// -----------------------------------------------------------------------------

// Função: gerarCronograma
// Descrição:
//     Gera e organiza um cronograma de cuidados baseado nos dados cadastrados.
void gerarCronograma();

#endif
