#ifndef SAIDA_H
#define SAIDA_H

// -----------------------------------------------------------------------------
// Módulo: saída
// Propósito:
//     Gerencia a apresentação de informações ao usuário, incluindo menus e
//     exibindo dados armazenados.
// -----------------------------------------------------------------------------

// Função: menu
// Descrição:
//     Exibe o menu principal do programa.
void menu();

// Função: mostrarUsuarios
// Descrição:
//     Exibe na tela todos os usuários cadastrados.
void mostrarUsuarios();

#endif
