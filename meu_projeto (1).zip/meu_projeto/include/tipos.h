#ifndef TIPOS_H
#define TIPOS_H

// -----------------------------------------------------------------------------
// Módulo: tipos
// Propósito: 
//     Define os tipos de dados utilizados em todo o programa, incluindo
//     constantes, structs e variáveis globais de armazenamento.
// -----------------------------------------------------------------------------

// Constantes globais:
//   - MAX: número máximo de usuários permitidos.
//   - TAM: tamanho máximo de strings armazenadas.
#define MAX 5
#define TAM 50

// -----------------------------------------------------------------------------
// Struct: Usuario
// Representa uma pessoa cadastrada no sistema.
// Campos:
//   - nome: nome completo do usuário.
//   - tipoCabelo: classificação do cabelo (ex: liso, ondulado, cacheado...).
//   - nivelDano: nível de dano percebido (ex: leve, médio, severo).
//   - objetivo: meta ou tratamento desejado pelo usuário.
// -----------------------------------------------------------------------------
typedef struct {
    char nome[TAM];
    char tipoCabelo[TAM];
    char nivelDano[TAM];
    char objetivo[TAM];
} Usuario;

// Variáveis globais:
//   - usuarios: vetor que armazena todos os usuários cadastrados.
//   - qtdUsuarios: quantidade atual de usuários no vetor.
extern Usuario usuarios[MAX];
extern int qtdUsuarios;

#endif
