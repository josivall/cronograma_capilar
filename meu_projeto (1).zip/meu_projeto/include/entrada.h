#ifndef ENTRADA_H
#define ENTRADA_H

// -----------------------------------------------------------------------------
// Módulo: entrada
// Propósito:
//     Responsável pela coleta de dados do usuário via entrada padrão.
//     Possui funções de leitura, validação e limpeza do buffer.
// -----------------------------------------------------------------------------

// Função: cadastrarUsuario
// Descrição:
//     Lê as informações de um novo usuário e armazena no vetor global.
void cadastrarUsuario();

// Função: limparBuffer
// Descrição:
//     Remove caracteres indesejados do buffer de entrada.
void limparBuffer();

#endif
