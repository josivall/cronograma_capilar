 
 /* 
 Projeto: Conograma_capilar
 Autor:jhonatan abreu dos santos
 julia de almeida bareira
Data de criação: [14/10/2025]
 Descrição: Estrutura inicial do projeto integrador.
*/

#include <stdio.h>

int main(void) {
    printf("Iniciando o Projeto Integrador...\n");
    return 0;
}